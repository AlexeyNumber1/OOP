package ua.opnu;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Objects;

public class Task {
    public static void main(String[] args) {

    }

    public void removeShorterStrings(List<String> list) {
        int index = 0;
        while (index + 1 < list.size()) {
            String first = list.get(index);
            String second = list.get(index + 1);

            if (first.length() <= second.length()) {
                list.remove(index);
            } else {
                list.remove(index + 1);
            }
            index++;
        }
    }

    public void stutter(List<String> list) {
        int index = 0;
        while (index < list.size()) {
            String current = list.get(index);
            list.add(index + 1, current);
            index += 2;
        }
    }

    public void switchPairs(List<String> list) {
        for (int i = 0; i + 1 < list.size(); i += 2) {
            String first = list.get(i);
            String second = list.get(i + 1);
            list.set(i, second);
            list.set(i + 1, first);
        }
    }

    public void removeDuplicates(List<String> list) {
        int i = 1;
        while (i < list.size()) {
            String prev = list.get(i - 1);
            String curr = list.get(i);
            if (prev == null ? curr == null : prev.equals(curr)) {
                list.remove(i);
            } else {
                i++;
            }
        }
    }

    public void markLength4(List<String> list) {
        int i = 0;
        while (i < list.size()) {
            String current = list.get(i);
            if (current != null && current.length() == 4) {
                list.add(i, "****");
                i += 2;
            } else {
                i++;
            }
        }
    }

    public boolean isPalindrome(Queue<Integer> queue) {
        if (queue == null || queue.isEmpty()) {
            return true;
        }

        int size = queue.size();
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        boolean palindrome = true;

        for (int i = 0; i < size; i++) {
            int value = queue.remove();
            stack.push(value);
            queue.add(value);
        }

        for (int i = 0; i < size; i++) {
            int value = queue.remove();
            int fromStack = stack.pop();
            if (value != fromStack) {
                palindrome = false;
            }
            queue.add(value);
        }

        return palindrome;
    }

    public void reorder(Queue<Integer> queue) {
        if (queue == null || queue.isEmpty()) {
            return;
        }

        int size = queue.size();
        ArrayDeque<Integer> stack = new ArrayDeque<>();

        for (int i = 0; i < size; i++) {
            stack.push(queue.remove());
        }

        for (int i = 0; i < size; i++) {
            int value = stack.pop();
            if (value < 0) {
                queue.add(value);
            } else {
                queue.add(value);
            }
        }

        int count = queue.size();
        for (int i = 0; i < count; i++) {
            int value = queue.remove();
            if (value < 0) {
                stack.push(value);
            } else {
                queue.add(value);
            }
        }

        while (!stack.isEmpty()) {
            queue.add(stack.pop());
        }

        int nonNegCount = queue.size();
        for (int i = 0; i < nonNegCount; i++) {
            int value = queue.remove();
            if (value >= 0) {
                stack.push(value);
            } else {
                queue.add(value);
            }
        }

        int negCount = queue.size();
        for (int i = 0; i < negCount; i++) {
            stack.push(queue.remove());
        }

        while (!stack.isEmpty()) {
            queue.add(stack.pop());
        }
    }

    public void rearrange(Queue<Integer> queue) {
        if (queue == null || queue.isEmpty()) {
            return;
        }

        int size = queue.size();
        ArrayDeque<Integer> stack = new ArrayDeque<>();

        for (int i = 0; i < size; i++) {
            int value = queue.remove();
            if (value % 2 == 0) {
                queue.add(value);
            } else {
                stack.push(value);
            }
        }

        int evenCount = queue.size();
        int oddCount = size - evenCount;

        while (!stack.isEmpty()) {
            queue.add(stack.pop());
        }

        for (int i = 0; i < evenCount; i++) {
            queue.add(queue.remove());
        }

        for (int i = 0; i < oddCount; i++) {
            stack.push(queue.remove());
        }

        while (!stack.isEmpty()) {
            queue.add(stack.pop());
        }
    }

    public int maxLength(Set<String> set) {
        if (set == null || set.isEmpty()) {
            return 0;
        }

        int max = 0;
        for (String s : set) {
            if (s != null && s.length() > max) {
                max = s.length();
            }
        }
        return max;
    }

    public void removeEvenLength(Set<String> set) {
        if (set == null || set.isEmpty()) {
            return;
        }

        set.removeIf(s -> s != null && s.length() % 2 == 0);
    }

    public int numInCommon(List<Integer> list1, List<Integer> list2) {
        if (list1 == null || list2 == null || list1.isEmpty() || list2.isEmpty()) {
            return 0;
        }

        Set<Integer> firstSet = new HashSet<>(list1);
        Set<Integer> commonSet = new HashSet<>();

        for (Integer value : list2) {
            if (firstSet.contains(value)) {
                commonSet.add(value);
            }
        }

        return commonSet.size();
    }

    public boolean isUnique(Map<String, String> map) {
        if (map == null || map.isEmpty()) {
            return true;
        }

        Set<String> seenValues = new HashSet<>();
        for (String value : map.values()) {
            if (!seenValues.add(value)) {
                return false;
            }
        }

        return true;
    }

    public Map<String, Integer> intersect(Map<String, Integer> map1, Map<String, Integer> map2) {
        Map<String, Integer> result = new HashMap<>();
        if (map1 == null || map2 == null || map1.isEmpty() || map2.isEmpty()) {
            return result;
        }

        for (Map.Entry<String, Integer> entry : map1.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            if (map2.containsKey(key) && Objects.equals(value, map2.get(key))) {
                result.put(key, value);
            }
        }

        return result;
    }

    public Map<String, Integer> reverse(Map<Integer, String> map) {
        Map<String, Integer> result = new HashMap<>();
        if (map == null || map.isEmpty()) {
            return result;
        }

        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            Integer key = entry.getKey();
            String value = entry.getValue();
            if (value != null) {
                result.put(value, key);
            }
        }

        return result;
    }

    public int rarest(Map<String, Integer> map) {
        if (map == null || map.isEmpty()) {
            return 0;
        }

        Map<Integer, Integer> counts = new HashMap<>();
        for (Integer value : map.values()) {
            if (value != null) {
                counts.put(value, counts.getOrDefault(value, 0) + 1);
            }
        }

        if (counts.isEmpty()) {
            return 0;
        }

        int rarestValue = 0;
        int minCount = Integer.MAX_VALUE;
        boolean hasValue = false;

        for (Map.Entry<Integer, Integer> entry : counts.entrySet()) {
            int val = entry.getKey();
            int freq = entry.getValue();

            if (!hasValue || freq < minCount || (freq == minCount && val < rarestValue)) {
                rarestValue = val;
                minCount = freq;
                hasValue = true;
            }
        }

        return rarestValue;
    }

    public int maxOccurrences(List<Integer> list) {
        if (list == null || list.isEmpty()) {
            return 0;
        }

        Map<Integer, Integer> counts = new HashMap<>();
        int maxCount = 0;

        for (Integer value : list) {
            if (value != null) {
                int updated = counts.getOrDefault(value, 0) + 1;
                counts.put(value, updated);
                if (updated > maxCount) {
                    maxCount = updated;
                }
            }
        }

        return maxCount;
    }
}
