import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

// Класс Student для завдань 2, 3, 4
class Student {
    private String name;
    private String group;
    private int[] marks;

    public Student(String name, String group, int[] marks) {
        this.name = name;
        this.group = group;
        this.marks = marks;
    }

    public String getName() {
        return name;
    }

    public String getGroup() {
        return group;
    }

    public int[] getMarks() {
        return marks;
    }

    @Override
    public String toString() {
        return name + " (" + group + "), оцінки: " + Arrays.toString(marks);
    }
}

public class Main {

    // Метод фільтрації для Завдання 2
    public static Student[] filter(Student[] input, Predicate<Student> predicate) {
        Student[] result = new Student[input.length];
        int counter = 0;
        for (Student student : input) {
            if (predicate.test(student)) {
                result[counter] = student;
                counter++;
            }
        }
        return Arrays.copyOfRange(result, 0, counter);
    }

    // Метод фільтрації за двома умовами (два предикати) для Завдання 3
    public static Student[] filter(Student[] input, Predicate<Student> p1, Predicate<Student> p2) {
        Student[] result = new Student[input.length];
        int counter = 0;
        for (Student student : input) {
            if (p1.test(student) && p2.test(student)) {
                result[counter] = student;
                counter++;
            }
        }
        return Arrays.copyOfRange(result, 0, counter);
    }

    // Метод forEach для Consumer у Завданні 4
    public static void forEach(Student[] input, Consumer<Student> consumer) {
        for (Student student : input) {
            consumer.accept(student);
        }
    }

    // Метод для Завдання 5 (виконує Consumer, якщо виконується умова Predicate)
    public static void processWithCondition(int[] input, Predicate<Integer> predicate, Consumer<Integer> consumer) {
        for (int i : input) {
            if (predicate.test(i)) {
                consumer.accept(i);
            }
        }
    }

    // Метод для Завдання 6 (обробка масиву через Function)
    public static int[] processArray(int[] input, Function<Integer, Integer> function) {
        int[] result = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = function.apply(input[i]);
        }
        return result;
    }

    // Метод stringify для Завдання 7
    public static String[] stringify(int[] input, Function<Integer, String> function) {
        String[] result = new String[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = function.apply(input[i]);
        }
        return result;
    }

    public static void main(String[] args) {

        System.out.println("=== ЗАВДАННЯ 1: Предикат (просте число) ===");
        Predicate<Integer> isPrime = n -> {
            if (n <= 1) return false;
            for (int i = 2; i <= Math.sqrt(n); i++) {
                if (n % i == 0) return false;
            }
            return true;
        };
        System.out.println("Чи є 2 простим: " + isPrime.test(2));   // true
        System.out.println("Чи є 4 простим: " + isPrime.test(4));   // false
        System.out.println("Чи є 17 простим: " + isPrime.test(17)); // true
        System.out.println("Чи є 1 простим: " + isPrime.test(1));   // false

        // Загальний масив студентів
        Student[] students = {
                new Student("Олександр Петренко", "ІП-21", new int[]{85, 90, 78}),
                new Student("Марія Коваль", "ІП-22", new int[]{92, 55, 88}), // має борг (55)
                new Student("Андрій Шевченко", "ІП-21", new int[]{65, 70, 65}),
                new Student("Ольга Іванова", "ІП-23", new int[]{45, 75, 50})  // має борги
        };


        System.out.println("\n=== ЗАВДАННЯ 2: Фільтрація студентів (без боргів < 60) ===");
        Predicate<Student> noDebts = student -> {
            for (int mark : student.getMarks()) {
                if (mark < 60) return false;
            }
            return true;
        };
        Student[] filtered1 = filter(students, noDebts);
        for (Student s : filtered1) {
            System.out.println(s);
        }


        System.out.println("\n=== ЗАВДАННЯ 3: Фільтрація за двома предикатами ===");
        // Умова 1: без заборгованостей, Умова 2: ім'я починається на 'О'
        Predicate<Student> startsWithO = s -> s.getName().startsWith("О");
        Student[] filtered2 = filter(students, noDebts, startsWithO);
        for (Student s : filtered2) {
            System.out.println(s);
        }


        System.out.println("\n=== ЗАВДАННЯ 4: Consumer (вивід ПРІЗВИЩЕ + ІМ'Я через forEach) ===");
        // Оскільки в нас є одне поле name, виводимо його повністю (або можна розбити за пробілом)
        Consumer<Student> printNameConsumer = s -> System.out.println(s.getName());
        forEach(students, printNameConsumer);


        System.out.println("\n=== ЗАВДАННЯ 5: Predicate + Consumer для масиву чисел ===");
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        Predicate<Integer> isEven = n -> n % 2 == 0;
        Consumer<Integer> printer = n -> System.out.println("Парне число: " + n);
        processWithCondition(numbers, isEven, printer);


        System.out.println("\n=== ЗАВДАННЯ 6: Function (обчислення 2^n) ===");
        Function<Integer, Integer> powerOfTwo = n -> (int) Math.pow(2, n);
        int[] powers = processArray(numbers, powerOfTwo);
        System.out.println(Arrays.toString(powers));


        System.out.println("\n=== ЗАВДАННЯ 7: stringify() (числа від 0 до 9 в рядки) ===");
        int[] digits = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        Function<Integer, String> numberToString = n -> {
            String[] words = {"нуль", "один", "два", "три", "чотири", "п'ять", "шість", "сім", "вісім", "дев'ять"};
            if (n >= 0 && n < words.length) {
                return words[n];
            }
            return String.valueOf(n);
        };
        String[] stringified = stringify(digits, numberToString);
        System.out.println(Arrays.toString(stringified));
    }
}