package org.example;

import org.example.model.BankAccount;
import org.example.model.CheckingAccount;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class ClientInterface {

    public static class BankingException extends RuntimeException {
        public BankingException(String message) {
            super(message);
        }

        public static class DuplicateUserIdException extends BankingException {
            public DuplicateUserIdException(Long userId) {
                super("Account with userId " + userId + " already exists");
            }
        }

        public static class InvalidPasswordException extends BankingException {
            public InvalidPasswordException(String message) {
                super(message);
            }
        }

        public static class PasswordMismatchException extends BankingException {
            public PasswordMismatchException() {
                super("Password and confirmation password do not match");
            }
        }

        public static class AccountNotFoundException extends BankingException {
            public AccountNotFoundException(Long userId) {
                super("Account with userId " + userId + " not found");
            }
        }

        public static class NonZeroBalanceException extends BankingException {
            public NonZeroBalanceException(double balance) {
                super("Cannot delete account with non-zero balance: " + balance);
            }
        }

        public static class InvalidAmountException extends BankingException {
            public InvalidAmountException(String message) {
                super(message);
            }
        }

        public static class WithdrawalLimitExceededException extends BankingException {
            public WithdrawalLimitExceededException(double amount, double limit) {
                super("Withdrawal amount " + amount + " exceeds daily limit " + limit);
            }
        }

        public static class InsufficientFundsException extends BankingException {
            public InsufficientFundsException(double amount, double balance) {
                super("Insufficient funds: requested " + amount + ", available " + balance);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        ClientInterface clientInterface = new ClientInterface();
        clientInterface.start();
    }

    private final List<BankAccount> accounts = new ArrayList<>();

    private final Scanner scanner = new Scanner(System.in);

    private List<String> options = List.of(
            "1 - Create account",
            "2 - Delete account",
            "3 - Make account deposit",
            "4 - Make account withdrawal",
            "5 - Print account info",
            "6 - Exit"
    );

    public void start() throws IOException {

        String option;
        while (true) {
            printMainMenu();
            option = scanner.next();

            try {
                switch (Integer.parseInt(option)) {
                    case 1:
                        addNewAccount();
                        break;
                    case 2:
                        deleteAccount();
                        break;
                    case 3:
                        deposit();
                        break;
                    case 4:
                        withdraw();
                        break;
                    case 5:
                        printInfo();
                        break;
                    case 6:
                        return;
                    default:
                        System.out.println("Please enter a valid choice (1 thru 6)");
                }
            } catch (NumberFormatException e) {
                System.err.println("Error: Please enter a valid number\n");
            } catch (BankingException e) {
                System.err.println("Error: " + e.getMessage() + "\n");
            }
        }

    }

    private void printMainMenu() throws IOException {
        System.out.println("\n****************");
        System.out.println("Banking system: ");
        System.out.println("****************");
        options.forEach(System.out::println);
        System.out.print("\n>>> Choose your option: ");
    }

    private void addNewAccount() {

        /*
         * В даному методі ви повинні передбачити перевірки для
         * коректності полів нового акаунту та створити новий акаунт, якщо всі дані
         * є коректними
         */

        System.out.println("\n****************");
        System.out.println("Creating new account: ");
        System.out.println("****************");

        System.out.print(">>> Enter customer name: ");
        var name = scanner.next();
        System.out.print(">>> Enter user id: ");
        var userId = scanner.next();
        System.out.print(">>> Enter user password: ");
        var password = scanner.next();
        System.out.print(">>> Confirm password: ");
        var confirmPassword = scanner.next();

        Long id = Long.parseLong(userId);
        for (BankAccount acc : accounts) {
            if (acc.getUserId().equals(id)) {
                throw new BankingException.DuplicateUserIdException(id);
            }
        }
        if (password.length() < 8 || password.chars().noneMatch(Character::isDigit)) {
            throw new BankingException.InvalidPasswordException("Password must be at least 8 characters and contain a digit");
        }
        if (!password.equals(confirmPassword)) {
            throw new BankingException.PasswordMismatchException();
        }
        accounts.add(new CheckingAccount(name, UUID.randomUUID().toString(), id, password));
        System.out.println("Account created successfully.\n");
    }

    private void deleteAccount() {

        /*
         * В даному методі ви повинні передбачити перевірки для
         * коректності полів для видалення акаунту та видалити акаунт
         */

        System.out.println("\n****************");
        System.out.println("Deleting account: ");
        System.out.println("****************");

        System.out.print(">>> Enter user id: ");
        var userId = scanner.next();
        System.out.print(">>> Enter user password: ");
        var password = scanner.next();

        BankAccount acc = getAccount(userId, password);
        if (acc.getAccountBalance() != 0.0) {
            throw new BankingException.NonZeroBalanceException(acc.getAccountBalance());
        }
        accounts.remove(acc);
        System.out.println("Account deleted successfully.\n");
    }

    private void deposit() {

        /*
         * В даному методі ви повинні передбачити перевірки для
         * коректності полів та зробити внесок
         */

        System.out.println("\n****************");
        System.out.println("Making a deposit: ");
        System.out.println("****************");

        System.out.print(">>> Enter user id: ");
        var userId = scanner.next();
        System.out.print(">>> Enter user password: ");
        var password = scanner.next();
        System.out.print(">>> Enter amount: ");
        var amount = scanner.next();

        BankAccount acc = getAccount(userId, password);
        acc.deposit(Double.parseDouble(amount));
        System.out.println("Deposit completed successfully.\n");
    }

    private void withdraw() {

        /*
         * В даному методі ви повинні передбачити перевірки для
         * коректності полів та зробити зняття коштів
         */

        System.out.println("\n****************");
        System.out.println("Making a withdrawal: ");
        System.out.println("****************");

        System.out.print(">>> Enter user id: ");
        var userId = scanner.next();
        System.out.print(">>> Enter user password: ");
        var password = scanner.next();
        System.out.print(">>> Enter amount: ");
        var amount = scanner.next();

        BankAccount acc = getAccount(userId, password);
        acc.withdraw(Double.parseDouble(amount));
        System.out.println("Withdrawal completed successfully.\n");
    }

    private void printInfo() {

        /*
         * Даний метод виводить інформацію щодо рахунку. Ви
         * повинні перевірити наявність рахунку та вивести інформацію
         * стосовно нього
         */

        System.out.println("\n****************");
        System.out.println("Printing account info: ");
        System.out.println("****************");

        System.out.print(">>> Enter user id: ");
        var userId = scanner.next();
        System.out.print(">>> Enter user password: ");
        var password = scanner.next();

        BankAccount acc = getAccount(userId, password);
        double limit = (acc instanceof CheckingAccount) ? ((CheckingAccount) acc).getDailyWithdrawalLimit() : 0.0;

        System.out.println("\nAccount info: ");

        System.out.println(" - customer name: "+ acc.getCustomerName());
        System.out.println(" - account balance: "+ acc.getAccountBalance());
        System.out.println(" - account type: "+ acc.getClass().getSimpleName());
        System.out.println(" - account daily withdrawal limit: "+ limit);

        System.out.print("\nPress Enter to return to main menu...");

        try {
            System.in.read();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private BankAccount getAccount(String userIdStr, String password) {
        Long id = Long.parseLong(userIdStr);
        for (BankAccount acc : accounts) {
            if (acc.getUserId().equals(id)) {
                if (!acc.getUserPassword().equals(password)) {
                    throw new BankingException.InvalidPasswordException("Wrong password");
                }
                return acc;
            }
        }
        throw new BankingException.AccountNotFoundException(id);
    }

}