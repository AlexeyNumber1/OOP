package org.example.model;

import org.example.ClientInterface.BankingException;

public class BankAccount {
    private String customerName;
    private String accountNumber;
    private Long userId;
    private String userPassword;
    private Double accountBalance;

    public BankAccount(String customerName, String accountNumber, Long userId, String userPassword) {
        this.customerName = customerName;
        this.accountNumber = accountNumber;
        this.userId = userId;
        this.userPassword = userPassword;
        this.accountBalance = 0.0;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public Double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Double accountBalance) {
        if (accountBalance == null || accountBalance < 0) {
            throw new BankingException.InvalidAmountException("Account balance cannot be negative");
        }
        this.accountBalance = accountBalance;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            throw new BankingException.InvalidAmountException("Deposit amount must be greater than 0");
        }
        this.accountBalance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            throw new BankingException.InvalidAmountException("Withdrawal amount must be greater than 0");
        }
        if (amount > this.accountBalance) {
            throw new BankingException.InsufficientFundsException(amount, this.accountBalance);
        }
        this.accountBalance -= amount;
    }
}
