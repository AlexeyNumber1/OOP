package org.example;

public class TimeSpan {
    private int hours;
    private int minutes;

    public TimeSpan() {
        this.hours = 0;
        this.minutes = 0;
    }

    public TimeSpan(int minutes) {
        if (minutes < 0) {
            throw new IllegalInputTimeSpanException("Minutes cannot be negative: " + minutes);
        }
        this.hours = minutes / 60;
        this.minutes = minutes % 60;
    }

    public TimeSpan(int hours, int minutes) {
        if (hours < 0 || minutes < 0 || minutes > 59) {
            throw new IllegalInputTimeSpanException(
                    "Invalid hours or minutes: hours=" + hours + ", minutes=" + minutes
            );
        }
        this.hours = hours + minutes / 60;
        this.minutes = minutes % 60;
    }

    public TimeSpan(TimeSpan span) {
        if (span == null) {
            throw new IllegalInputTimeSpanException("TimeSpan cannot be null");
        }
        this.hours = span.getHours();
        this.minutes = span.getMinutes();
    }

    public int getHours() {
        return this.hours;
    }

    public int getMinutes() {
        return this.minutes;
    }

    public void add(int hours, int minutes) {
        if (hours < 0 || minutes < 0 || minutes > 59) {
            throw new IllegalInputTimeSpanException(
                    "Invalid hours or minutes: hours=" + hours + ", minutes=" + minutes
            );
        }
        this.hours += hours + minutes / 60;
        this.minutes += minutes % 60;
        this.hours += this.minutes / 60;
        this.minutes %= 60;
    }

    public void add(int minutes) {
        if (minutes < 0) {
            throw new IllegalInputTimeSpanException("Minutes cannot be negative: " + minutes);
        }
        this.add(0, minutes % 60);
        this.hours += minutes / 60;
    }

    public void add(TimeSpan span) {
        if (span == null) {
            throw new IllegalInputTimeSpanException("TimeSpan cannot be null");
        }
        this.add(span.getHours(), span.getMinutes());
    }

    public void subtract(int hours, int minutes) {
        if (hours < 0 || minutes < 0 || minutes > 59) {
            throw new IllegalInputTimeSpanException(
                    "Invalid hours or minutes: hours=" + hours + ", minutes=" + minutes
            );
        }
        int totalCurrentMinutes = this.hours * 60 + this.minutes;
        int totalSubtractMinutes = hours * 60 + minutes;
        if (totalSubtractMinutes > totalCurrentMinutes) {
            throw new NegativeTimeSpanException("Resulting TimeSpan cannot be negative");
        }
        int remainingMinutes = totalCurrentMinutes - totalSubtractMinutes;
        this.hours = remainingMinutes / 60;
        this.minutes = remainingMinutes % 60;
    }

    public void subtract(int minutes) {
        if (minutes < 0) {
            throw new IllegalInputTimeSpanException("Minutes cannot be negative: " + minutes);
        }
        int totalCurrentMinutes = this.hours * 60 + this.minutes;
        if (minutes > totalCurrentMinutes) {
            throw new NegativeTimeSpanException("Resulting TimeSpan cannot be negative");
        }
        int remainingMinutes = totalCurrentMinutes - minutes;
        this.hours = remainingMinutes / 60;
        this.minutes = remainingMinutes % 60;
    }

    public void subtract(TimeSpan span) {
        if (span == null) {
            throw new IllegalInputTimeSpanException("TimeSpan cannot be null");
        }
        int totalCurrentMinutes = this.hours * 60 + this.minutes;
        int totalSubtractMinutes = span.getHours() * 60 + span.getMinutes();
        if (totalSubtractMinutes > totalCurrentMinutes) {
            throw new NegativeTimeSpanException("Resulting TimeSpan cannot be negative");
        }
        int remainingMinutes = totalCurrentMinutes - totalSubtractMinutes;
        this.hours = remainingMinutes / 60;
        this.minutes = remainingMinutes % 60;
    }

    public double getTotalHours() {
        return (double) this.hours + (double) this.minutes / 60.0;
    }

    public int getTotalMinutes() {
        return this.hours * 60 + this.minutes;
    }

    public void scale(int factor) {
        if (factor <= 0) {
            throw new IllegalScaleFactorException("Scale factor must be positive: " + factor);
        }
        int totalMinutes = (this.hours * 60 + this.minutes) * factor;
        this.hours = totalMinutes / 60;
        this.minutes = totalMinutes % 60;
    }

    public static class NegativeTimeSpanException extends RuntimeException {
        public NegativeTimeSpanException() {
            super("TimeSpan cannot be negative");
        }

        public NegativeTimeSpanException(String message) {
            super(message);
        }
    }

    public static class IllegalInputTimeSpanException extends RuntimeException {
        public IllegalInputTimeSpanException() {
            super("Invalid input TimeSpan values");
        }

        public IllegalInputTimeSpanException(String message) {
            super(message);
        }
    }

    public static class IllegalScaleFactorException extends RuntimeException {
        public IllegalScaleFactorException() {
            super("Invalid scale factor");
        }

        public IllegalScaleFactorException(String message) {
            super(message);
        }
    }
}
