package org.example.model;

import org.example.ClientInterface.BankingException;

public class CheckingAccount extends BankAccount {
    private double dailyWithdrawalLimit = 300.0;

    public CheckingAccount(String customerName, String accountNumber, Long userId, String userPassword) {
        super(customerName, accountNumber, userId, userPassword);
    }

    public double getDailyWithdrawalLimit() {
        return dailyWithdrawalLimit;
    }

    public void setDailyWithdrawalLimit(double dailyWithdrawalLimit) {
        if (dailyWithdrawalLimit < 0) {
            throw new BankingException.InvalidAmountException("Daily withdrawal limit cannot be negative");
        }
        this.dailyWithdrawalLimit = dailyWithdrawalLimit;
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount);
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            throw new BankingException.InvalidAmountException("Withdrawal amount must be greater than 0");
        }
        if (amount > this.dailyWithdrawalLimit) {
            throw new BankingException.WithdrawalLimitExceededException(amount, this.dailyWithdrawalLimit);
        }
        super.withdraw(amount);
    }
}
