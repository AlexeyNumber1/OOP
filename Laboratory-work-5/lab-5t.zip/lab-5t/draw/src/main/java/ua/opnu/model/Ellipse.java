package ua.opnu.model;

import ua.opnu.view.DrawFrame;

import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Ellipse extends DrawShape {
    public Ellipse() {
        super();
    }

    public Ellipse(Point startPoint, Point endPoint) {
        super(startPoint, endPoint);
    }

    @Override
    public Shape getShape(Point startPoint, Point endPoint) {
        int x = Math.min(startPoint.x, endPoint.x);
        int y = Math.min(startPoint.y, endPoint.y);
        int width = Math.abs(startPoint.x - endPoint.x);
        int height = Math.abs(startPoint.y - endPoint.y);

        return new Ellipse2D.Double(x, y, width, height);
    }
}
