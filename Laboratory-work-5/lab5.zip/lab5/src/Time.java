class TimeSpan {
    private int hours;
    private int minutes;

    public TimeSpan() {
    this.hours = 0;
    this.minutes = 0;
    }

    public TimeSpan(int minutes) {
        if (minutes < 0) {
            minutes = 0;
        }
        this.hours = minutes / 60;
        this.minutes = minutes % 60;
    }

    public TimeSpan(int hours, int minutes) {
        if (hours < 0) {
            hours = 0;
        }
        if (minutes < 0) {
            minutes = 0;
        }
        this.hours = hours + (minutes / 60);
        this.minutes = minutes % 60;
    }

    public TimeSpan(TimeSpan span) {
        this.hours = span.getHours();
        this.minutes = span.getMinutes();
    }

    public int getHours() {
        return hours;
    }

    public int getMinutes() {
        return minutes;
    }
    public void add(int hours, int minutes) {
        if (hours < 0) {
            hours = 0;
        }
        if (minutes < 0) {
            minutes = 0;
        }
        this.hours += hours + (minutes / 60);
        this.minutes += minutes % 60;

        this.hours += this.minutes / 60;
        this.minutes %= 60;
    }

    public void add(int minutes) {
        if (minutes < 0) {
            minutes = 0;
        }
        add(0, minutes);
    }

    public void add(TimeSpan span) {
        if (span != null) {
            add(span.getHours(), span.getMinutes());
        }
    }

    public void subtract(int hours, int minutes) {
        if (hours < 0) {
            hours = 0;
        }
        if (minutes < 0) {
            minutes = 0;
        }

        int totalCurrentMinutes = this.hours * 60 + this.minutes;
        int totalSubtractMinutes = hours * 60 + minutes;

        if (totalSubtractMinutes > totalCurrentMinutes) {
            return;
        }

        int remainingMinutes = totalCurrentMinutes - totalSubtractMinutes;
        this.hours = remainingMinutes / 60;
        this.minutes = remainingMinutes % 60;
    }

    public void subtract(int minutes) {
        if (minutes < 0) {
            minutes = 0;
        }
        subtract(0, minutes);
    }

    public void subtract(TimeSpan span) {
        if (span != null) {
            subtract(span.getHours(), span.getMinutes());
        }
    }

    public double getTotalHours() {
        return hours + (minutes / 60.0);
    }

    public int getTotalMinutes() {
        return hours * 60 + minutes;
    }

    public void scale(int factor) {
        if (factor <= 0) {
            factor = 0;
        }
        int totalMinutes = (hours * 60 + minutes) * factor;
        this.hours = totalMinutes / 60;
        this.minutes = totalMinutes % 60;
    }
}

public class Time {
    public static void main(String[] args) {
        TimeSpan first = new TimeSpan();
        TimeSpan second = new TimeSpan(150);
        TimeSpan third = new TimeSpan(2, 30);
        TimeSpan copy = new TimeSpan(third);

        third.add(1, 45);
        third.add(30);
        third.add(second);
        third.subtract(1, 15);
        third.subtract(30);
        third.subtract(second);

        double hours = third.getTotalHours();
        int minutes = third.getTotalMinutes();

        third.scale(2);

        System.out.println("Hours: " + third.getHours());
        System.out.println("Minutes: " + third.getMinutes());
    }
}