class Person {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Людина: " + lastName + " " + firstName + ", вік: " + age;
    }
}

class Student extends Person {
    private String group;
    private String studentId;

    public Student(String firstName, String lastName, int age, String group, String studentId) {
        super(firstName, lastName, age);
        this.group = group;
        this.studentId = studentId;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return "Студент групи " + group + ", " + getLastName() + " " + getFirstName() + ", вік: " + getAge() + ". Номер студентського квитка: " + studentId;
    }
}

class Lecturer extends Person {
    private String department;
    private double salary;

    public Lecturer(String firstName, String lastName, int age, String department, double salary) {
        super(firstName, lastName, age);
        this.department = department;
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Викладач кафедри " + department + ", " + getLastName() + " " + getFirstName() + ", вік: " + getAge() + ". Зарплата: " + salary;
    }
}

public class University {
    public static void main(String[] args) {
        Person student1 = new Student("Андрій", "Ярмоленко", 18, "АІ-252", "27608461");
        Person student2 = new Student("Анна", "Коваль", 19, "АІ-244", "34801407");
        Person student3 = new Student("Олексій", "Ющенко", 17, "АІ-263", "91730861");
        Person student4 = new Student("Віталій", "Іванов", 20, "АІ-235", "13070817");
        Person student5 = new Student("Вікторія", "Шевченко", 18, "АІ-254", "61762384");
        Person lecturer1 = new Lecturer("Геннадій", "Степанюк", 44, "Інформаційних систем", 40000);
        Person lecturer2 = new Lecturer("Валентина", "Михайлова", 51, "Інформаційних технологій", 45000);
        Person lecturer3 = new Lecturer("Надія", "Федорова", 53, "Інженерія програмного забезпечення", 35000);

        Person[] people = {student1, student2, student3, student4, student5, lecturer1, lecturer2, lecturer3};

        for (Person p: people) {
            System.out.println(p.toString());
        }
    }
}