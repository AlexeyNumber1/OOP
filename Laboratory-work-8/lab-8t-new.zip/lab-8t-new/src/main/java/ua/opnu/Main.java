package ua.opnu;

import java.util.Arrays;
import java.util.function.Predicate;

public class Main {
    
    // ЗАВДАННЯ 1: Клас MyOptional<T>
    public static class MyOptional<T> {
        // 1. Приватні поля
        private T value;
        private boolean present; // означає, що значення реально існує всередині

        public MyOptional() {
            this.value = null;
            this.present = false; // present == false означає "значення відсутнє"
        }

        public MyOptional(T value) {
            if (value == null) {
                throw new IllegalArgumentException("MyOptional не приймає null");
            }
            this.value = value;
            this.present = true;
        }

        public boolean isPresent() {
            return present;
        }

        public boolean isEmpty() {
            return !isPresent();
        }

        public T get() {
            if (!present) {
                throw new IllegalStateException("Значення відсутнє");
            }
            return value;
        }

        public T orElse(T defaultValue) {
            return present ? value : defaultValue;
        }

        @Override
        public String toString() {
            if (present) {
                return "MyOptional[value=" + value + "]";
            } else {
                return "MyOptional[empty]";
            }
        }
    }


    // ЗАВДАННЯ 2: Клас BookData з інтерфейсом Comparable
    public static class BookData implements Comparable<BookData> {
        private String title;
        private String author;
        private int reviews;
        private double total;

        public BookData(String title, String author, int reviews, double total) {
            this.title = title;
            this.author = author;
            this.reviews = reviews;
            this.total = total;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public int getReviews() {
            return reviews;
        }

        public double getTotal() {
            return total;
        }

        public double getRating() {
            if (reviews == 0) {
                return 0.0;
            }
            return total / reviews;
        }

        @Override
        public int compareTo(BookData other) {
            double thisRating = this.getRating();
            double otherRating = other.getRating();

            int ratingComparison = Double.compare(otherRating, thisRating);
            if (ratingComparison != 0) {
                return ratingComparison;
            }

            return this.title.compareTo(other.title);
        }

        @Override
        public String toString() {
            return "\"" + title + "\" — " + author + " (Рейтинг: " + getRating() + ")";
        }
    }


    // ЗАВДАННЯ 3: Клас Printer з узагальненим методом printArray
    public static class Printer {
        // Узагальнений метод для друку елементів масиву будь-якого типу по черзі з нової лінії
        public <T> void printArray(T[] array) {
            for (T element : array) {
                System.out.println(element);
            }
        }
    }


    // ЗАВДАННЯ 4: Узагальнений метод filter (вдосконалений)
    public static <T> T[] filter(T[] input, Predicate<T> p) {
        // Створюємо масив точного типу вхідного масиву за допомогою рефлексії
        T[] result = (T[]) java.lang.reflect.Array.newInstance(input.getClass().getComponentType(), input.length);

        int counter = 0;
        for (T i : input) {
            if (p.test(i)) {
                result[counter] = i;
                counter++;
            }
        }

        return Arrays.copyOfRange(result, 0, counter);
    }


    // ЗАВДАННЯ 5: Узагальнений метод contains
    public static <T extends Comparable<T>, V extends T> boolean contains(T[] array, V element) {
        if (array == null || element == null) {
            return false;
        }
        for (T item : array) {
            if (item != null && item.compareTo(element) == 0) {
                return true;
            }
        }
        return false;
    }


    // ЗАВДАННЯ 6: Узагальнені кортежі GenericTwoTuple та GenericThreeTuple
    public static class GenericTwoTuple<T, V> {
        public final T first;
        public final V second;

        public GenericTwoTuple(T first, V second) {
            this.first = first;
            this.second = second;
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }

    public static class GenericThreeTuple<T, V, S> {
        public final GenericTwoTuple<T, V> twoTuple;
        public final S three;

        public GenericThreeTuple(T first, V second, S three) {
            this.twoTuple = new GenericTwoTuple<>(first, second);
            this.three = three;
        }

        public T getFirst() {
            return twoTuple.first;
        }

        public V getSecond() {
            return twoTuple.second;
        }

        public S getThree() {
            return three;
        }

        @Override
        public String toString() {
            return "(" + twoTuple.first + ", " + twoTuple.second + ", " + three + ")";
        }
    }


    public static void main(String[] args) {

        System.out.println("--- ТЕСТИ ЗАВДАННЯ 1 (MyOptional) ---");


        MyOptional<String> middleName = new MyOptional<>();
        System.out.println(middleName); // MyOptional[empty]
        System.out.println("isPresent: " + middleName.isPresent()); // false
        System.out.println("orElse: " + middleName.orElse("немає")); // "немає"

        MyOptional<String> username = new MyOptional<>("admin");
        System.out.println(username); // MyOptional[value=admin]
        System.out.println("isPresent: " + username.isPresent()); // true
        System.out.println("get(): " + username.get()); // "admin"
        System.out.println("orElse: " + username.orElse("guest")); // "admin"

        try {
            String test = middleName.get(); // має кинути IllegalStateException
            System.out.println("unexpected: " + test);
        } catch (IllegalStateException ex) {
            System.out.println("Очікуваний виняток: " + ex.getMessage());
        }

        try {
            MyOptional<String> broken = new MyOptional<>(null);
            System.out.println("unexpected: " + broken);
        } catch (IllegalArgumentException ex) {
            System.out.println("Правильно не дозволив null: " + ex.getMessage());
        }


        System.out.println("\n--- ТЕСТИ ЗАВДАННЯ 2 (BookData) ---");

        BookData book1 = new BookData("Книга 1", "Автор A", 10, 40.0); // рейтинг 4.0
        BookData book2 = new BookData("Книга 2", "Автор Б", 5, 24.5);  // рейтинг 4.9

        System.out.println(book1);
        System.out.println(book2);

        System.out.println("Результат compareTo між книгою 1 та книгою 2: " + book1.compareTo(book2));


        System.out.println("\n--- ТЕСТИ ЗАВДАННЯ 3 (Printer) ---");

        Printer myPrinter = new Printer();
        Integer[] intArray = {1, 2, 3};
        String[] stringArray = {"Hello", "World"};

        myPrinter.printArray(intArray);
        myPrinter.printArray(stringArray);


        System.out.println("\n--- ТЕСТИ ЗАВДАННЯ 4 (filter) ---");

        String[] words = {"Кіт", "Кавун", "Автомобіль", "Дім"};
        String[] filteredWords = filter(words, s -> s.length() > 4);
        System.out.println("Відфільтровані слова (довжина > 4): " + Arrays.toString(filteredWords));


        System.out.println("\n--- ТЕСТИ ЗАВДАННЯ 5 (contains) ---");

        String[] searchArray = {"Java", "Python", "C++"};
        boolean hasJava = contains(searchArray, "Java");
        boolean hasRuby = contains(searchArray, "Ruby");
        System.out.println("Містить 'Java': " + hasJava);   // true
        System.out.println("Містить 'Ruby': " + hasRuby);   // false


        System.out.println("\n--- ТЕСТИ ЗАВДАННЯ 6 (Tuples) ---");

        GenericTwoTuple<String, Integer> studentTuple = new GenericTwoTuple<>("Іван Петренко", 95);
        System.out.println("GenericTwoTuple: " + studentTuple);

        GenericThreeTuple<String, Integer, String> detailedTuple = new GenericThreeTuple<>("Марія Коваль", 88, "Факультет ІТ");
        System.out.println("GenericThreeTuple: " + detailedTuple);
    }
}
