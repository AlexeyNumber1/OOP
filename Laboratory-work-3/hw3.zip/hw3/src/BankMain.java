class VulnerableBankAccount {
    public int balance;

    public VulnerableBankAccount(int balance) {
        this.balance = balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public void deposit(int amount) {
        balance += amount;
    }

    public void withdraw(int amount) {
        balance -= amount;
    }

    public int getBalance() {
        return balance;
    }
}

class BankAccount {
    private int[] data;

    public BankAccount (int initialBalance) {
        data = new int[1];
        if (initialBalance < 0) {
            System.out.println("Помилка: початковий баланс не може бути від'ємним! Рахунок створено з балансом 0.");
            this.data[0] = 0;
        } else {
            this.data[0] = initialBalance;
        }
    }

    public void deposit(int amount) {
        if (amount < 0) {
            System.out.println("Помилка поповнення: сума повинна бути більшою за 0!");
            return;
        }
        data[0] += amount;
    }

    public boolean withdraw(int amount) {
        if (amount <= 0) {
            System.out.println("Помилка зняття: сума повинна бути більшою за 0!");
            return false;
        }
        if (amount > data[0]) {
            System.out.println("Помилка зняття: недостатньо коштів на рахунку!");
            return false;
        }
        data[0] -= amount;
        System.out.println("Зняття на суму "+ amount + " пройшло успішно!");
        return true;
    }

    public int getBalance() {
        return data[0];
    }
}

public class BankMain {
    public static void main(String[] args) {

        System.out.println("Процес зламання нашого балансу роблячи його від'ємним\n");
        VulnerableBankAccount bankAccount1 = new VulnerableBankAccount(-5000);
        System.out.println("Спосіб 1 (Від'ємний баланс через конструктор)\nВаш баланс: " + bankAccount1.balance + " грн");

        VulnerableBankAccount bankAccount2 = new VulnerableBankAccount(1000);
        bankAccount2.balance = -999999;
        System.out.println("\nСпосіб 2 (Прямий запис у public-полі) \nВаш баланс: " + bankAccount2.balance + " грн");

        VulnerableBankAccount bankAccount3 = new VulnerableBankAccount(500);
        bankAccount3.setBalance(-200);
        System.out.println("\nСпосіб 3 (Використання setBalance) \nВаш баланс: " + bankAccount3.balance + " грн");


        System.out.println("\n\n\nТестування виправленого завдання");
        BankAccount account = new BankAccount(5000);
        System.out.println("Початковий баланс: " + account.getBalance() + " грн");

        account.deposit(1500);
        System.out.println("\nПоповнимо на картку трохи грошей\nБаланс: " + account.getBalance() + " грн");

        System.out.println("\nСпробуємо зняти трохи грошей");
        boolean success1 = account.withdraw(2500);
        System.out.println("Баланс: " + account.getBalance() + " грн");

        System.out.println("\nСпробуємо зняти більше грошей ніж є");
        boolean success2 = account.withdraw(10000);
        System.out.println("Баланс: " + account.getBalance() + " грн");

        System.out.println("\nСпробуємо поповнити від'ємну кількість грошей");
        account.deposit(-500);

        System.out.println("\nФінальний баланс рахунку: " + account.getBalance() + " грн");
    }
}