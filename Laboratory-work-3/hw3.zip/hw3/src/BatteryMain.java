class Battery {
    private int capacity;
    private int charge;

    public Battery(int capacity, int initialCharge) {
        if (capacity <= 0) {
            System.out.println("Помилка! Ємність не може бути менше за 1!");
            this.capacity = 1;
        } else {
            this.capacity = capacity;
        }

        if (initialCharge < 0) {
            System.out.println("Помилка! Заряд не може бути від'ємним!");
            this.charge = 0;
        } else if (initialCharge > this.capacity) {
            System.out.println("Помилка! Заряд не може бути більшим за ємність!");
            this.charge = this.capacity;
        } else {
            this.charge = initialCharge;
        }
    }

    public boolean use(int amount) {
        if (amount < 0) {
            System.out.println("Заборонено використовувати від'ємну кількість енергії!");
            return false;
        }
        if (this.charge < amount) {
            System.out.println("Недостатньо заряду для використання " + amount + " (доступно: " + this.charge + ").");
            return false;
        }

        this.charge -= amount;
        return true;
    }

    public boolean chargeBattery(int amount) {
        if (amount < 0) {
            System.out.println("Неможливо зарядити на від'ємну кількість енергії1");
            return false;
        }

        int newCharge = this.charge + amount;

        if (newCharge > this.capacity) {
            System.out.println("Перевищення ємності! Поточний заряд: " + this.charge);
            return false;
        }
        this.charge = newCharge;
        return true;
    }

    public int getCharge() {
        return this.charge;
    }

    public int getCapacity() {
        return capacity;
    }
}


public class BatteryMain {
    public static void main(String[] args) {
        Battery battery = new Battery(100, 40);
        System.out.println("Початковий стан: заряд = " + battery.getCharge() + ", ємність = " + battery.getCapacity());

        System.out.println("\nЗаряджаємо на 40");
        boolean success1 = battery.chargeBattery(40);
        System.out.println("Результат: " + success1);
        System.out.println("Поточний заряд: " + battery.getCharge());

        System.out.println("\nЗаряджаємо на максимум");
        boolean success2 = battery.chargeBattery(20);
        System.out.println("Результат: " + success2);
        System.out.println("Поточний заряд: " + battery.getCharge());

        System.out.println("\nСпробуємо перевищити ємність");
        boolean success3 = battery.chargeBattery(10);
        System.out.println("Результат: " + success3);
        System.out.println("Поточний заряд: " + battery.getCharge());

        System.out.println("\nСпробуємо перевищити енергію");
        boolean success4 = battery.use(150);
        System.out.println("Результат: " + success4);

        System.out.println("\nКінцевий стан об'єкта: заряд = " + battery.getCharge() + ", ємність = " + battery.getCapacity());
    }
}
